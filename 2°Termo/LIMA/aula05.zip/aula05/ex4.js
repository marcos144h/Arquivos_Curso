const entrada = require("readline-sync");
console.log("===REGIOSTRO DE TEMPERATURA===");
const temperaturas = [];
const quantidade = entrada.questionInt("quantos temperaturas desejam registrar?");
for (let i= 0; i < quantidade; i++){
    let temperatura = entrada.questionFloat(`temperatura ${i+1}:`);
    temperaturas.push(temperatura);
}
console.log("\n--RELATORIO---");
console.log(`temperatura registradas:${temperaturas.join(" °C | ")}°C`);
console.log(`quantidade de registros: ${temperaturas.length} `);
console.log(`ultimo  registro: ${temperaturas[0]}°c `);
console.log(`ultimo registro:${temperatura[temperaturas.length -1]}°c`);
console.log(`maior temperatura ${maior}`)
