let quantidade = parseInt(prompt("Digite a quantidade de peças:"));
let somaTotal = 0;

if (quantidade > 0) {
  for (let i = 1; i <= quantidade; i++) {
    let peso = parseFloat(prompt(`Digite o peso da peça ${i}:`));
    somaTotal += peso;
  }

  let media = somaTotal / quantidade;

  console.log("Soma total:", somaTotal.toFixed(2));
  console.log("Média dos pesos:", media.toFixed(2));
} else {
  console.log("Quantidade inválida!");
}