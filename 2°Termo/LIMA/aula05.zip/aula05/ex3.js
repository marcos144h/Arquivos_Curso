//const alunos =["ana", "bruno" ,"carlos", "enzo","marcos","josiane"];

//console.log("lista dos alunos: ");
//console.log(alunos);

//console.log(` primeiro aluno : ${alunos[0]}`);
//console.log(`segundo aluno : ${alunos[1]}`);
//console.log(`quantidades de alunos: ${alunos.length}`);


// acresentar  mais 2  nomes ao array
// mostrar o terceiro aluno
// mostrar o ultimo aluno
const alunos =["ana", "bruno" ,"carlos", "enzo","marcos","josiane"];

console.log("lista dos alunos: ");
console.log(alunos);

console.log(` primeiro aluno : ${alunos[0]}`);
console.log(` segundo aluno : ${alunos[1]}`);
console.log(` terceiro aluno : ${alunos[2]}`);
console.log(`segundo aluno : ${alunos[3]}`);
console.log(`quantidades de alunos: ${alunos.length}`);


alunos.push("carlos");
alunos.push("marcos");


console.log(` primeiro aluno : ${alunos[0]}`);
console.log(` segundo aluno : ${alunos[1]}`);
console.log(` terceiro aluno : ${alunos[2]}`);
