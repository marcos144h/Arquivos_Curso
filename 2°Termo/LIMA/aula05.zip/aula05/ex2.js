const alunos =["ana", "bruno" ,"carlos", "enzo"];
console.log(`o primeiro aluno da lista e: ${aluno[0]}`);
console.log(`quantidades de alunos: ${alunos.length}`);